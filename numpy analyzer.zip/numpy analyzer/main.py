from data_analytics import DataAnalytics

def main():
    """Main block."""
           
    print("\nWelcome to the NumPy Analyzer!")
    analyzer=DataAnalytics()

    try:
    
        while True:
                print("\nChoose an Option : ")
                print("1. Create a NumPy Array")
                print("2. Indexing and Slicing")
                print("3. Perform Mathematical Operations")
                print("4. Combine or split arrays")
                print("5. Search, Sort, and Filter arrays")
                print("6. Compute Aggregates and Statistics")
                print("7. Exit")
            
            
                ch = int(input("Enter your choice: "))

                if ch == 1:
                    analyzer.Create_Array()

                elif ch == 2:
                    analyzer.Indexing_And_Slicing()

                elif ch == 3:
                    analyzer.Mathematical_Operations()

                elif ch == 4:
                    analyzer.Combine_And_Split()

                elif ch == 5:
                    analyzer.Search_Sort_Filter()

                elif ch == 6:
                    analyzer.Aggregates()

                elif ch == 7:
                    print("\nThank you for using the NumPy Analyzer! :)")
                    break

                else:
                    print("Invalid Choice! Please select in 1-7 range\n")

    except Exception:
        print("Invalid input! Please enter a integer.")


if __name__ == "__main__":
    main()