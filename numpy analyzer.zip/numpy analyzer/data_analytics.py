from methods import ArrayCreation as arr
from methods import IndexingAndSlicing as ins
from methods import MathOperations as mo
from methods import CombineAndSplit as cs
from methods import SearchSortFilter as ssf
from methods import Aggregation as ag


class DataAnalytics:
    """Class to perform NumPy array operations"""

    def __init__(self):
        self.array = None

    # method to check if array exists
    def Check_Array(self):
        """Check if array exists"""
        if self.array is None:
            print("No array created! Please create an array first.")
            return False
        return True

    # create array
    def Create_Array(self):
        self.array = arr.CreateArray()

        if self.array is not None:
            print("\nArray Created Successfully :)")
            print(self.array)
            print("")

    # indexing and slicing
    def Indexing_And_Slicing(self):
        if self.Check_Array():
            ins.IndexingAndSlicing(self.array)

    # mathematical operations
    def Mathematical_Operations(self):
        if self.Check_Array():
            mo.MathematicalOperations(self.array)

    # combine and split arrays
    def Combine_And_Split(self):
        if self.Check_Array():
            cs.CombineAndSplit(self.array)

    # search, sort, and filter
    def Search_Sort_Filter(self):
        if self.Check_Array():
            ssf.SearchSortFilter(self.array)

    # aggregate statistics
    def Aggregates(self):
        if self.Check_Array():
            ag.AggregateStatics(self.array)
            