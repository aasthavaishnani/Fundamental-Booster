import numpy as np

def SearchSortFilter(array):
    """Perform search, sort and filter operations on the given array"""
    try:
        while True:
            
            print("\n choose the operation to perform :\n")
            print("1. Search for an element")
            print("2. Sort the array")
            print("3. Filter elements based on a condition")
            print("4. Back To Main Menue")
            
            ch = int(input("Enter your choice (1-4) : "))
            
            print("\nOriginal Array :")
            print(array)
            print()
            
            if ch == 1:
                # if 1d array
                if array.ndim == 1:
                    element = int(input("Enter the element to search for : "))
                    indices = np.where(array == element)[0]
                    if len(indices) > 0:
                        print(f"\nElement {element} found at index/indices : {indices}")
                    else:
                        print(f"\nElement {element} not found in the array.")

                # if 2d array
                elif array.ndim == 2:
                    element = int(input("Enter the element to search for : "))
                    indices = np.argwhere(array == element)
                    if len(indices) > 0:
                        print(f"\nElement {element} found at index/indices : {indices}")
                    else:
                        print(f"\nElement {element} not found in the array.")
                
                # if 3d array
                elif array.ndim == 3:
                    element = int(input("Enter the element to search for : "))
                    indices = np.argwhere(array == element)
                    if len(indices) > 0:
                        print(f"\nElement {element} found at index/indices : {indices}")
                    else:
                        print(f"\nElement {element} not found in the array.")
                    
                else:
                    print("Searching for elements in arrays with more than 2 dimensions is not supported in this demo.")

            elif ch == 2:
                # if 1d array
                if array.ndim == 1:
                    sorted_array = np.sort(array)
                    print("\nSorted Array :")
                    print(sorted_array)

                # if 2d array
                elif array.ndim == 2:
                    print("Sort by : ")
                    print("1. Sort by rows")
                    print("2. Sort by columns")
                    sort_ch = int(input("Enter your choice (1-2) : "))
                    if sort_ch == 1:
                        sorted_array = np.sort(array, axis=1)  # Sort each row
                        print("\nSorted Array (sorted by rows) :")
                        print(sorted_array)
                    elif sort_ch == 2:
                        sorted_array = np.sort(array, axis=0)  # Sort each column
                        print("\nSorted Array (sorted by columns) :")
                        print(sorted_array)
                    else:
                        print("Invalid choice for sorting. Please select 1 or 2.")

                # if 3d array
                elif array.ndim == 3:
                    print("Sort by : ")
                    print("1. Sort by depth layers")
                    print("2. Sort by rows")
                    print("3. Sort by columns")
                    sort_ch = int(input("Enter your choice (1-3) : "))
                    if sort_ch == 1:
                        sorted_array = np.sort(array, axis=0)  # Sort each depth layer
                        print("\nSorted Array (sorted by depth layers) :")
                        print(sorted_array)
                    elif sort_ch == 2:
                        sorted_array = np.sort(array, axis=1)  # Sort each row
                        print("\nSorted Array (sorted by rows) :")
                        print(sorted_array)
                    elif sort_ch == 3:
                        sorted_array = np.sort(array, axis=2)  # Sort each column
                        print("\nSorted Array (sorted by columns) :")
                        print(sorted_array)
                    else:
                        print("Invalid choice for sorting. Please select 1, 2 or 3.")

                else:
                    print("Sorting arrays with more than 2 dimensions is not supported in this demo.")
                
            elif ch == 3:
                condition = input("Enter the condition (e.g., '> 5', '<= 10') : ")
                filtered_array = eval(f"array {condition}")
                print(f"\nElements that satisfy the condition '{condition}' :")
                print(filtered_array)
                 
            elif ch == 4:
                break
                
            else:
                print("Invalid Choice ! Please select in 1-4 range !")
            
    except Exception:
        print("\nInvalid input ! Please enter valid integers for choice and element, and a valid condition !")
        
if __name__ == "__main__":
    SearchSortFilter(np.array([1, 2, 3, 4, 5]))