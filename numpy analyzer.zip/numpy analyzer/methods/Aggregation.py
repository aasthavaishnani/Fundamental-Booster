import numpy as np

def AggregateStatics(array):
    """Perform aggregate statistics operations on the given array"""
    
    try:
        while True:   
            print("\nchoose the aggregate statistics operation to perform :")
            print("1. Sum")
            print("2. Mean")
            print("3. Median")
            print("4. Standard Deviation")
            print("5. Variance")
            print("6. Back To Menu\n")
            
            
            ch = int(input("Enter your choice (1-5) : "))
            
            print("\nOriginal Array :")
            print(array)
            
            if ch == 1:
                result = np.sum(array)
                print(f"\nSum : {result}")
                
            elif ch == 2:
                result = np.mean(array)
                print(f"\nMean : {result}")
                
            elif ch == 3:
                result = np.median(array)
                print(f"\nMedian : {result}")
                
            elif ch == 4:
                result = np.std(array)
                print(f"\nStandard Deviation : {result}")
            
            elif ch == 5:
                result = np.var(array)
                print(f"\nVariance : {result}")
                
            elif ch == 6:
                break
            
            else:
                print("\nInvalid Choice ! Please select in 1-6 range !")
            
    except Exception:
        print("\nInvalid input ! Please enter valid integers for choice !")   
        

if __name__ == "__main__":
    AggregateStatics()
