import numpy as np

def MathematicalOperations(array):
    """Perform mathematical operations on the given array"""
    try:
        while True:
            
            print("\nchoose the mathematical operation to perform :\n")
            print("1. Addition")
            print("2. Subtraction")
            print("3. Multiplication")
            print("4. Division")
            print("5. Dot Product / Matrix Multiplication")
            print("6. Back To Main Menu")
            
            
            ch = int(input("Enter your choice (1-6) : "))
            
            # if ch not in [1,2,3,4]:
            #     print("\nInvalid Choice ! Please choose a valid option (1-4)")
            #     print()
            #     return

            # number = int(input("Enter the number to perform the operation with : "))
            
            # print("\nOriginal Array :")
            # print(array)
            
            # if ch == 1:
            #     result = array + number
            #     print(f"\nResult of Addition with {number} : ")
            #     print(result)
            #     print("")
                
            # elif ch == 2:
            #     result = array - number
            #     print(f"\nResult of Substraction with {number} : ")
            #     print(result)
            #     print("")
                
            # elif ch == 3:
            #     result = array * number
            #     print(f"\nResult of Multiplication with {number} : ")
            #     print(result)
            #     print("")
                
            # elif ch == 4:
            #     result = array / number
            #     print(f"\nResult of Division with {number} : ")
            #     print(result)
            #     print("")
                
            # elif ch == 5:
            #     break
                
            # else:
            #     print("Invalid Choice ! Please choose a valid option (1-4)\n")

            if ch == 6:
                break

            if ch not in [1, 2, 3, 4, 5]:
                print("\nInvalid Choice ! Please select in 1-6 range !")
                continue

            if ch in [1, 2, 3, 4]:
                size = array.size
                ele = input(f"Enter the same-size array elements ({size} elements separated by space) : ")

                enteredarray = np.array([x for x in ele.split()], dtype=int).reshape(array.shape)

                print("\nOriginal Array :")
                print(array)
                print("\nEntered Array :")
                print(enteredarray)

                if ch == 1:
                    result = array + enteredarray
                    print(f"\nAddition : ")

                elif ch == 2:
                    result = array - enteredarray
                    print(f"\nSubtraction : ")

                elif ch == 3:
                    result = array * enteredarray
                    print(f"\nMultiplication : ")

                elif ch == 4:
                    result = array / enteredarray
                    print(f"\nDivision : ")

                print(result)

            elif ch == 5:
                print(f"\nCurrent Array Shape: {array.shape}")
                ele = input("Enter elements for second array (separated by space): ")

                enteredarray = np.array([x for x in ele.split()], dtype=int)

                print("\nOriginal Array :")
                print(array)
                
                # if 1d array
                if array.ndim == 1:
                    result = np.dot(array, enteredarray)
                    print(f"\nResult of Dot Product: {result}")

                # if 2d 3d array
                elif array.ndim in [2, 3]:
                    required_rows = array.shape[-1]
                    print(f"Note: Second array must have {required_rows} rows.")
                    ele = input(f"Enter elements (multiples of {required_rows}) separated by space: ")

                    rawdata = np.array([x for x in ele.split()], dtype=int)
                    enteredarray = rawdata.reshape(required_rows, -1)

                    print("\nEntered Array (reshaped for compatibility):")
                    print(enteredarray)

                    result = np.dot(array, enteredarray)
                    print(f"\nResult of Matrix Multiplication: ")
                    print(result)

                else:
                    print("Dot product/matrix multiplication for arrays with more than 3 dimensions is not supported in this demo.\n")

    except Exception:
        print("Invalid input! Ensure you entered the correct number of elements for the array shape. !")
            

if __name__ == "__main__":
    MathematicalOperations(np.array([1, 2, 3, 4, 5]))