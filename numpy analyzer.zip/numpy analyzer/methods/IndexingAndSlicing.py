import numpy as np

def IndexingAndSlicing(array):
    """function to demostrate indexing and slicing operations on a array"""
    try:
        while True:

            print("\n1. Indexing array")
            print("2. Slicing array")
            print("3. Back To Main Menu")

            ch = int(input("Enter your choice (1-3): "))

            if ch == 1:
                print("\nIndexing array : ")

                # if 1d array
                if array.ndim == 1:
                    index = int(input("Enter the index to access: "))
                    if 0 <= index < len(array):
                        print(f"\nElement at index {index} : {array[index]}\n")
                    else:
                        print("Invalid index\n")

                # if 2d array
                elif array.ndim == 2:
                    row = int(input("Enter the row index to access: "))
                    col = int(input("Enter the column index to access: "))
                    if 0 <= row < array.shape[0] and 0 <= col < array.shape[1]:
                        print(f"\nElement at index [{row}, {col}] : {array[row, col]}\n")
                    else:
                        print("Invalid row or column index\n")

                # if 3d array
                if array.ndim == 3:
                    depth = int(input("Enter the depth index to access: "))
                    row = int(input("Enter the row index to access: "))
                    col = int(input("Enter the column index to access: "))
                    if 0 <= depth < array.shape[0] and 0 <= row < array.shape[1] and 0 <= col < array.shape[2]:
                        print(f"\nElement at index [{depth}, {row}, {col}] : {array[depth, row, col]}\n")
                    else:
                        print("Invalid depth, row or column index\n")

                else:
                    print("Indexing for arrays with more than 3 dimensions is not supported in this demo.\n")
                    
            elif ch == 2:
                print("\nSlicing Operation")
                # if 1d array
                if array.ndim == 1:
                    start = int(input("Enter the start index for slicing: "))
                    end = int(input("Enter the end index for slicing: "))
                    if 0 <= start < len(array) and 0 <= end <= len(array) and start < end:
                        print(f"\nSliced array from index {start} to {end} : {array[start:end]}\n")
                    else:
                        print("Invalid start or end index\n")

                # if 2d array
                elif array.ndim == 2:
                    row_start = int(input("Enter the start row index for slicing: "))
                    row_end = int(input("Enter the end row index for slicing: "))
                    col_start = int(input("Enter the start column index for slicing: "))
                    col_end = int(input("Enter the end column index for slicing: "))
                    if 0 <= row_start < array.shape[0] and 0 <= row_end <= array.shape[0] and 0 <= col_start < array.shape[1] and 0 <= col_end <= array.shape[1] and row_start < row_end and col_start < col_end:
                        print(f"\nSliced array from rows {row_start} to {row_end} and columns {col_start} to {col_end} :\n{array[row_start:row_end, col_start:col_end]}\n")
                    else:
                        print("Invalid row or column indices\n")

                # if 3d array
                elif array.ndim == 3:
                    depth_start = int(input("Enter the start depth index for slicing: "))
                    depth_end = int(input("Enter the end depth index for slicing: "))
                    row_start = int(input("Enter the start row index for slicing: "))
                    row_end = int(input("Enter the end row index for slicing: "))
                    col_start = int(input("Enter the start column index for slicing: "))
                    col_end = int(input("Enter the end column index for slicing: "))
                    if 0 <= depth_start < array.shape[0] and 0 <= depth_end <= array.shape[0] and 0 <= row_start < array.shape[1] and 0 <= row_end <= array.shape[1] and 0 <= col_start < array.shape[2] and 0 <= col_end <= array.shape[2] and depth_start < depth_end and row_start < row_end and col_start < col_end:
                        print(f"\nSliced array from depths {depth_start} to {depth_end}, rows {row_start} to {row_end} and columns {col_start} to {col_end} :\n{array[depth_start:depth_end, row_start:row_end, col_start:col_end]}\n")
                    else:
                        print("Invalid depth, row or column indices\n")
                
                else:
                    print("Indexing for arrays with more than 3 dimensions is not supported in this demo.\n")
                 
            elif ch == 3:
                break
                    
            else:
                print("\nInvalid choice. Please enter a number between 1 and 3.\n")
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    IndexingAndSlicing(np.array([1, 2, 3, 4, 5]))