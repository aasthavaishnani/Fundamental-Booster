import numpy as np 

def CombineAndSplit(array, axis=0):
    """Combine and split the given array along the specified axis"""
    try:
        while True:

            print("\nSelect operation to perform : ")
            print("1. Combine arrays")
            print("2. Split arrays")
            print("3. Back To Main Menu")
            
            ch = int(input("\nEnter your choice: "))
            
            if ch == 1:
                # if 1d array
                if array.ndim == 1:
                    num_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays_to_combine = []
                    for i in range(num_arrays):
                        arr_input = input(f"Enter array {i + 1} (space separated values): ")
                        arr = np.array([int(x.strip()) for x in arr_input.split(" ")])
                        arrays_to_combine.append(arr)
                    combined_array = np.concatenate(arrays_to_combine)
                    print("\nCombined Array:")
                    print(combined_array)

                # if 2d array
                elif array.ndim == 2:
                    num_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays_to_combine = []
                    for i in range(num_arrays):
                        arr_input = input(f"Enter array {i + 1} (space separated values for each row, semicolon-separated rows): ")
                        arr = np.array([[int(x.strip()) for x in row.split(" ")] for row in arr_input.split(";")])
                        arrays_to_combine.append(arr)
                    combined_array = np.concatenate(arrays_to_combine, axis=axis)
                    print("\nCombined Array:")
                    print(combined_array)

                # if 3d array
                elif array.ndim == 3:
                    num_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays_to_combine = []
                    for i in range(num_arrays):
                        arr_input = input(f"Enter array {i + 1} (space separated values for each row, semicolon-separated rows): ")
                        arr = np.array([[[int(x.strip()) for x in cell.split(" ")] for cell in row.split(";")] for row in arr_input.split(";")])
                        arrays_to_combine.append(arr)
                    combined_array = np.concatenate(arrays_to_combine, axis=axis)
                    print("\nCombined Array:")
                    print(combined_array)

                else:
                    print("Combining arrays with more than 2 dimensions is not supported in this demo.")
            
            elif ch == 2:
                # if 1d array
                if array.ndim == 1:
                    num_splits = int(input("Enter the number of splits: "))
                    split_arrays = np.array_split(array, num_splits)
                    print("\nSplit Arrays:")
                    for i, split in enumerate(split_arrays):
                        print(f"Split {i + 1}: {split}")

                # if 2d array
                # Note: For 2D arrays, we will split along the specified axis (0 for rows, 1 for columns)
                elif array.ndim == 2:
                    num_splits = int(input("Enter the number of splits: "))
                    split_arrays = np.array_split(array, num_splits, axis=axis)
                    print("\nSplit Arrays:")
                    for i, split in enumerate(split_arrays):
                        print(f"Split {i + 1}:\n{split}")

                # if 3d array
                # For 3D arrays, we will split along the specified axis (0 for depth, 1 for rows, 2 for columns)
                # This is a simplified example and may not cover all edge cases for 3D array splitting.
                elif array.ndim == 3:
                    num_splits = int(input("Enter the number of splits: "))
                    split_arrays = np.array_split(array, num_splits, axis=axis)
                    print("\nSplit Arrays:")
                    for i, split in enumerate(split_arrays):
                        print(f"Split {i + 1}:\n{split}") 

                else:
                    print("Splitting arrays with more than 3 dimensions is not supported in this demo.")
                    
            elif ch == 3:
                break
                            
            else:
                print("\nInvalid choice. Please select 1 or 2.")
                
    except Exception as e:
        print(f"Error: {e}")
        

if __name__ == "__main__":
    CombineAndSplit(np.array([1, 2, 3, 4, 5]))