from modules.datahandles import DataHandler
from modules.visualization import Visualization
from modules.tracker import ExpenseTracker

def main():
    filepath = 'expenses.csv'

    datahandler = DataHandler(filepath)
    df = datahandler.LoadData()
    df = datahandler.CleanData(df)

    tracker = ExpenseTracker(df)

    while True:
        print("\n--- Smart Expense Tracker Menu ---")
        print("1. Add New Expense")
        print("2. View Summary (Total/Average)")
        print("3. Generate Category Report")
        print("4. Show Visualizations (Charts)")
        print("5. Save & Exit")
        
        ch = input("Enter your choice (1-5): ")

        if ch == '1':
            try:
                date = input("Enter date (YYYY-MM-DD): ")
                category = input("Enter category (e.g., Food, Transport): ")
                amount = float(input("Enter amount: "))
                if amount < 0:
                    print("Amount cannot be negative. Please try again.")
                    continue
                description = input("Enter description (optional): ")

                added = tracker.add_expense(date, category, amount, description)
                if added:
                    print(added)
                    print("Expense added successfully. :)")
            
            except ValueError:
                print("Invalid input. Please enter valid values.")

        elif ch == '2':
            summary = tracker.get_summary()
            print("\n--- Expense Summary ---")
            for key, value in summary.items():
                if isinstance(value, dict):
                    print(f"{key}:")
                    for cat, amt in value.items():
                        print(f"  - {cat}: {amt:.2f}")
                else:
                    print(f"{key}: {value:.2f}")

        elif ch == '3':
            report = tracker.generate_report()
            print("\n--- Category Report ---")
            print(f"{'Total Spending'}: {float(report['Total Expenses'])}")
            print(f"{'Average per Transaction'}: {float(report['Average Expense'])}")
            print(f"{'Highest Single Expense'}: {float(report['Maximum Expense'])}\n")

            print(f"{'CATEGORY':<15} {'AMOUNT (RS)':>15}")
            print("-" * 30)
            for category, total in report['Expenses by Category'].items():
                print(f"{category:15} {float(total):>15.2f}")

        elif ch == '4':
            viz = Visualization(tracker.df)
            print("\nWhich chart would you like to generate?")

            print("1. Bar Chart (Category wise)")
            print("2. Line Graph (Spending Trend)")
            print("3. Pie Chart (Distribution)")
            print("4. Histogram (Amount Frequency)")
            
            chh = input("Choice (1-4): ").lower()

            if chh == '1':
                viz.plot_category_expenses()
            elif chh == '2':
                viz.plot_expense_trend()        
            elif chh == '3':
                viz.plot_expense_distribution()
            elif chh == '4':
                viz.plot_amount_frequency()
            else:
                print("Invalid choice. Please select a valid chart option.")

        elif ch == '5':
            datahandler.SaveDataAsCSV(tracker.df)
            print("Exiting the application. Goodbye! :)")
            break

        else:
            print("Invalid choice! please select in 1-5 range.")

if __name__ == "__main__":
    main()