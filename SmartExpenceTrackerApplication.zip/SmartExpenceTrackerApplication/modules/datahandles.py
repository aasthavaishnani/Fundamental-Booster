import pandas as pd
import numpy as np
import os

class DataHandler:
    def __init__(self, filepath):
        self.filepath = filepath

    def LoadData(self):
        """Load data from a CSV file."""

        if os.path.exists(self.filepath):
            try:
                df = pd.read_csv(self.filepath)
                df['Date'] = pd.to_datetime(df['Date'])
                return df
            
            except Exception as e:
                print(f"Error loading data: {e}")
                return self.CreateEmptyDataFrame()
            
        else:
            print("Data file not found. Creating a new one.")
            return self.CreateEmptyDataFrame()
        
    def CreateEmptyDataFrame(self):
        """Create an empty DataFrame with the required columns."""
        
        columns = ['Date', 'Category', 'Amount', 'Description']
        return pd.DataFrame(columns=columns)
    
    def SaveDataAsCSV(self, df):
        """Save DataFrame to a CSV file."""
        try:
            df.to_csv(self.filepath, index=False)
            print(f"Data saved successfully to {self.filepath}. :)")

        except Exception as e:
            print(f"Error saving data: {e}")

    def CleanData(self, df):
        """Clean data by handling missing values """

        df['Amount'] = df['Amount'].replace(np.nan, 0)
        df['Description'] = df['Description'].fillna('No description')

        df = df.dropna(subset=['Date', 'Category'])

        df = df.drop_duplicates()

        return df
    
def main():
    print("This module is for data handling. Please run the main application to see it in action.")

if __name__ == "__main__":
    main()