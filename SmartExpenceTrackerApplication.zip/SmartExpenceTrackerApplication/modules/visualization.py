import matplotlib.pyplot as plt
import seaborn as sns

class Visualization:
    def __init__(self, dataframe):
        self.df = dataframe
        sns.set_style("whitegrid")

    def plot_category_expenses(self):
        """Bar chart of total expenses by category."""

        plt.figure(figsize=(10, 6))
        CategoryData = self.df.groupby('Category')['Amount'].sum()

        sns.barplot(x=CategoryData.index, y=CategoryData.values, palette='deep')

        plt.title('CATEGORY WISE TOTAL EXPENSES')
        plt.xlabel('Category')
        plt.ylabel('Total Amount')
        plt.show()

    def plot_expense_trend(self):
        """Line chart of spending trends over time."""
        plt.figure(figsize=(10, 6))
        TrendDtata = self.df.groupby('Date')['Amount'].sum().reset_index()
        
        sns.lineplot(data=TrendDtata, x='Date', y='Amount', marker='o', color='b')
        
        plt.title('SPENDING TRENDS OVER TIME')
        plt.xticks(rotation=45)
        plt.show()

    def plot_expense_distribution(self):
        """Pie Chart of proportional spending distribution by category."""
        plt.figure(figsize=(8, 8))
        CategoryDist = self.df.groupby('Category')['Amount'].sum()
        
        plt.pie(CategoryDist, labels=CategoryDist.index, autopct='%1.1f%%', startangle=90, colors=sns.color_palette('pastel'))
        
        plt.title('EXPENSE DISTRIBUTION BY CATEGORY')
        plt.show()

    def plot_amount_frequency(self):
        """Histogram of frequency of expense amounts."""
        plt.figure(figsize=(10, 6))
        
        sns.histplot(self.df['Amount'], bins=15, kde=True, color='skyblue')
        
        plt.title('FREQUENCY OF EXPENSE AMOUNTS')
        plt.xlabel('Amount Range')
        plt.ylabel('Frequency')
        plt.show()

def main():
    print("This module is for visualizations. Please run the main application to see it in action.")

if __name__ == "__main__":
    main()