import numpy as np
import pandas as pd

class ExpenseTracker:
    def __init__(self, dataframe):
        self.df = dataframe

    def add_expense(self, date, category, amount, description):
        """Add a new expense to the DataFrame."""

        new_expense = {
            'Date': pd.to_datetime(date),
            'Category': category,
            'Amount': float(amount),
            'Description': description
        }
        self.df = pd.concat([self.df, pd.DataFrame([new_expense])], ignore_index=True)
        return f"Added expense: {category} - {amount:.2f} on {date}"

    def get_summary(self):
        """Get a summary of total and average expenses."""

        amount = self.df['Amount'].values

        summary = {
            "Total Expenses": np.sum(amount),
            "Average Expense": np.mean(amount),
            "Maximum Expense": np.max(amount),
            "Expenses by Category": self.df.groupby('Category')['Amount'].sum().to_dict()
        }
        return summary

    def filter_expenses(self, condition):
        """Filter expenses based on a Category, date range, or amount."""

        if 'Category' in condition:
            filtered = self.df[self.df['Category'] == condition['Category']]
        
        elif 'DateRange' in condition:
            start_date, end_date = condition['DateRange']
            filtered = self.df[(self.df['Date'] >= pd.to_datetime(start_date)) & (self.df['Date'] <= pd.to_datetime(end_date))]
        
        elif 'AmountGreaterThan' in condition:
            filtered = self.df[self.df['Amount'] > condition['AmountGreaterThan']]
        
        else:
            print("Invalid filter condition.")
            return pd.DataFrame()  # Return empty DataFrame for invalid condition

        return filtered

    def generate_report(self):
        """Output a summary report with key metrics."""

        report = {
            "Total Expenses": np.sum(self.df['Amount']),
            "Average Expense": np.mean(self.df['Amount']),
            "Maximum Expense": np.max(self.df['Amount']),
            "Expenses by Category": self.df.groupby('Category')['Amount'].sum().to_dict()
        }
        return report
    
def main():
    print("This is the Expense Tracker module. Please run main.py to use the application.")

if __name__ == "__main__":
    main()