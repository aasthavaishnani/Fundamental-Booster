import sys
import uuid
from subModules import Datetime_nd_Time as dt
from subModules import Math as mt
from subModules import Random_Generation as rg
from subModules import File_Operations as fo

def generate_uuid():
    """Generates a unique identifier using uuid4."""
    try:
        unique_id = uuid.uuid4()
        print(f"Generated UUID: {unique_id}")
    except Exception as e:
        print(f"Error generating UUID: {e}")

def explore_module_attributes():
    """Dynamically explores module attributes using dir()."""
    print("\n--- Dynamic Module Exploration ---")
    print("Available modules to explore: dt, mt, sys, uuid, rg, fo")
    module_ch = input("Enter module alias to explore: ")

    try:
        if module_ch == 'dt':
            print(f"\nAttributes in Datetime_nd_Time:\n{dir(dt)}")
        elif module_ch == 'mt':
            print(f"\nAttributes in Math:\n{dir(mt)}")
        elif module_ch == 'sys':
            print(f"\nAttributes in sys:\n{dir(sys)}")
        elif module_ch == 'uuid':
            print(f"\nAttributes in uuid:\n{dir(uuid)}")
        elif module_ch == 'rg':
            print(f"\nAttributes in Random_Generation:\n{dir(rg)}")
        elif module_ch == 'fo':
            print(f"\nAttributes in File_Operations:\n{dir(fo)}")
        else:
            print("Invalid module choice. Please choose from dt, mt, sys, uuid, rg, or fo.")
            return
        
    except Exception as e:
        print(f"Error: {e}")

def main_menu():
    """Main execution logic."""

    print("Welcome to the Multi-Utility Toolkit!")
    try:
        while True:

            print("\nMenu:")
            print("1. Datetime and Time Operations")
            print("2. Mathematical Operations")
            print("3. Random Data Generation")
            print("4. Generate Unique Identifiers (UUID)")
            print("5. File Operations (Custom Module)")
            print("6. Explore Module Attributes (dir())")
            print("7. Exit")

            ch = input("Enter your choice: ")

            if ch == '1':
                dt.Display_Datetime_Menu()

            elif ch == '2':
                mt.Display_Math_Menu()

            elif ch == '3':
                rg.Display_Random_Menu()

            elif ch == '4':
                generate_uuid()

            elif ch == '5':
                fo.Display_File_Menu()

            elif ch == '6':
                explore_module_attributes()

            elif ch == '7':
                print("Thank you for using the Multi-Utility Toolkit!")
                sys.exit() # program mathi exit thava mate couse we are in main_menu loop

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main_menu()