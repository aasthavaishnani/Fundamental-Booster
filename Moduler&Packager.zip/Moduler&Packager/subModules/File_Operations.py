import os

def Create_File():
    """Creates a new file."""

    file_name = input("\nEnter file name: ")

    try:
        with open(file_name, 'x') as f:
            pass
        print(f"\nFile '{file_name}' created successfully!")

    except FileExistsError:
        print(f"File {file_name} already exists. Please choose a different name.")

def Write_To_File():
    """Writes data to a file."""

    file_name = input("\nEnter file name: ")
    data = input("Enter data to write: ")

    try:
        with open(file_name, 'w') as f:
            f.write(data)
        print(f"Data written to file '{file_name}' successfully!")

    except FileNotFoundError:
        print(f"\nFile {file_name} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError writing to file: {e}")

def Read_From_File():
    """Reads data from a file."""

    file_name = input("\nEnter file name: ")

    try:
        with open(file_name, 'r') as f:
            print("File Content:")
            print(f.read())

    except FileNotFoundError:
        print(f"\nFile {file_name} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError reading from file: {e}")

def Append_To_File():
    """Appends data to an existing file."""

    file_name = input("\nEnter file name: ")
    data = input("Enter data to append: ")

    try:
        with open(file_name, 'a') as f:
            f.write(data + '\n')
        print(f"Data appended to file '{file_name}' successfully!")

    except FileNotFoundError:
        print(f"\nFile {file_name} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError appending to file: {e}")

def Delete_File():
    """Deletes a file."""

    file_name = input("\nEnter file name to delete: ")

    try:
        os.remove(file_name)
        print(f"File '{file_name}' deleted successfully!")

    except FileNotFoundError:
        print(f"\nFile {file_name} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError deleting file: {e}")

def Display_File_Menu():
    """Displays the File Operations menu."""

    try:
        while True:
            print("\nFile Operations:")
            print("1. Create a new file")
            print("2. Write to a file")
            print("3. Read from a file")
            print("4. Append to a file")
            print("5. Delete a file")
            print("6. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == '1':
                Create_File()
            
            elif choice == '2':
                Write_To_File()
            
            elif choice == '3':
                Read_From_File()
            
            elif choice == '4':
                Append_To_File()
            
            elif choice == '5':
                Delete_File()
            
            elif choice == '6':
                break
            
            else:
                print("\nInvalid choice. Please try again.")
    
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    Display_File_Menu()