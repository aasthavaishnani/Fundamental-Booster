import math
from secrets import choice

def Factorial(n):
    """Calculate the factorial of a number."""

    try :
        print(f"Factorial: {math.factorial(n)}")

    except ValueError:
        print("\nFactorial is not defined for negative numbers.")
    except Exception as e:
        print(f"\nError: {e}")

def Compound_Interest(p, r, t):
    """Calculate compound interest."""
    try:
        amount = p * math.pow((1 + r / 100), t)
        interest = amount - p
        print(f"\nCompound Interest: {amount:.2f}")
        print(f"Interest: {interest:.2f}")
    
    except Exception as e:
        print(f"\nError: {e}")    

def Trigonometric_Calculations():
    """Calculates sin, cos, tan by converting degrees to radians."""

    angle = float(input("\nEnter angle in degrees: "))
    func = input("Enter function (sin/cos/tan): ")
    try:
        radians = math.radians(angle)

        if func.lower() == 'sin':
            result = math.sin(radians)
        elif func.lower() == 'cos':
            result = math.cos(radians)
        elif func.lower() == 'tan':
            result = math.tan(radians)
        else:
            print("\nInvalid function. Please choose 'sin', 'cos', or 'tan'.")
            return
        
        print(f"\n{func}({angle} degrees) = {result:.4f}")

    except Exception as e:  
        print(f"\nError: {e}")

def Area_of_Shapes():
    """Calculates area of different geometric shapes."""

    while True:
        try:
            print("\n1. Area of Circle")
            print("2. Area of Rectangle")
            print("3. Area of Triangle")
            print("4. Back to Main Menu")

            ch = input("Enter your choice: ")
            
            if ch == '1':
                area_circle()
            
            elif ch == '2':
                area_rectangle()
            
            elif ch == '3':
                area_triangle()
            
            elif ch == '4':
                return
            
            else:
                print("\nInvalid choice. Please try again.")
            
        except ValueError:
            print("\nInvalid input. Please enter numeric values.")
        except Exception as e:
            print(f"\nError: {e}")

def area_circle():
    radius = float(input("\nEnter the radius: "))
    area = math.pi * math.pow(radius, 2)
    print(f"Area of Circle: {area:.2f}")

def area_rectangle():
    length = float(input("\nEnter the length : "))
    width = float(input("Enter the width : "))
    area = length * width
    print(f"Area of Rectangle: {area:.2f}")

def area_triangle():    
    base = float(input("\nEnter the base : "))
    height = float(input("Enter the height : "))
    area = 0.5 * base * height
    print(f"Area of Triangle: {area:.2f}")

def Display_Math_Menu():
    """Displays the Mathematical Operations menu."""

    try:
        while True:
            print("\nMathematical Operations:")
            print("1. Factorial")
            print("2. Compound Interest")
            print("3. Trigonometric Calculations")
            print("4. Area of Shapes")
            print("5. Back to Main Menu")

            ch = input("Enter your choice: ")

            if ch == '1':
                n = int(input("\nEnter a number to calculate factorial: "))
                Factorial(n)
            
            elif ch == '2':
                p = float(input("\nEnter principal amount: "))
                r = float(input("Enter annual interest rate (in %): "))
                t = float(input("Enter time (in years): "))
                Compound_Interest(p, r, t)
            
            elif ch == '3':
                Trigonometric_Calculations()
            
            elif ch == '4':
                Area_of_Shapes()
            
            elif ch == '5':
                break
            
            else:
                print("\nInvalid choice. Please try again.")

    except ValueError:
        print("\nInvalid input. Please enter numeric values where required.")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":  
    Display_Math_Menu()