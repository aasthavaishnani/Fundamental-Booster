import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

class SalesDataAnalyzer:
    def __init__(self):
        """Constructor for initialization the DataFrame and show welcome screen."""
        self.data = None 
        self.currentfig = None 
        print("\n" + "="*60)
        print("   --- PANDAS ANALYZER & DATA VISUALIZATION SYSTEM ---   ")
        print("="*60)

    def __del__(self):
        """Destructor to clean up resources like open plots and data memory."""
        try:
            plt.close('all') 
            
            if self.data is not None:
                del self.data
            
            print("\n" + "─" * 60)
            print("[System] Resources released. Memory cleared successfully.")
            print("─" * 60)
        except Exception:
            pass

    def load_data(self, file_path):
        """Load data from a CSV file into a DataFrame."""
        print(f"\n[System] Accessing file: {file_path}...")

        try:
            if os.path.exists(file_path) and file_path.endswith('.csv'):
                self.data = pd.read_csv(file_path, encoding='unicode_escape')
                print(f"|--- Success: Dataset loaded! Records: {len(self.data)}")
            else:
                print("|--- Error: Invalid file path or not a CSV file.")
        except Exception as e:
            print(f"|--- Critical Error: {e}")
            
    def explore_data(self):
        """Detailed exploration of the dataset."""

        try:
            while True:
                if self.data is not None:
                    print("\n" + "="*20 + " EXPLORE DATA MENU " + "="*20)
                    print("1. View Top 5 Records")
                    print("2. View Bottom 5 Records")
                    print("3. List All Column Names")
                    print("4. Check Data Types of Columns")
                    print("5. View Full Dataset Summary")
                    print("6. Show Number of Rows and Columns")
                    print("7. Return to Main Menu")
                    
                    ch = input("\nSelect Sub-Option (1-7): ")

                    print("-" * 50)
                    if ch == '1': 
                        print(f"Top 5 Records:\n{self.data.head().to_string()}")
                    elif ch == '2': 
                        print(f"Bottom 5 Records:\n{self.data.tail().to_string()}")
                    elif ch == '3': 
                        print(f"Columns in Dataset: \n{self.data.columns.tolist()}")
                    elif ch == '4': 
                        print(f"Data Types: \n{self.data.dtypes}")
                    elif ch == '5': 
                        print(self.data.info())
                    elif ch == '6':
                        print(f"Dataset Dimensions: {self.data.shape[0]} Rows, {self.data.shape[1]} Columns")
                    elif ch == '7': 
                        break
                    else:
                        print("Invalid selection. Please try again.")
                else:
                    print("\nAccess Denied: Dataset not loaded. Please use Option 1 first.")
                    break

        except Exception as e:
            print(f"\nExploration Error: {e}")

    def clean_data(self):
        """Comprehensive data cleaning and missing value management."""

        try:
            while True:
                if self.data is not None:
                    print("\n" + "="*20 + " DATA CLEANING " + "="*20)
                    print(f"Current Null Values Count:\n{self.data.isnull().sum()}")
                    print("-" * 50)
                    print("1. Display only rows with missing values")
                    print("2. Fill missing numeric values with Column Mean")
                    print("3. Drop all rows containing any missing value")
                    print("4. Replace NULLs with a custom value (Manual)")
                    print("5. Return to Main Menu")
                    
                    ch = input("\nAction Choice (1-5): ")
                    
                    if ch == '1':
                        missing_rows = self.data[self.data.isnull().any(axis=1)]
                        print(f"Rows with Missing Values:\n{missing_rows.to_string()}" if not missing_rows.empty else "No missing values found!")

                    elif ch == '2':
                        self.data.fillna(self.data.mean(numeric_only=True), inplace=True)
                        print("Process Complete: Numeric columns filled with mean.")

                    elif ch == '3':
                        self.data.dropna(inplace=True)
                        print("Process Complete: Rows with null values removed.")
                        print(f"Remaining Records: {self.data.shape[0]}")

                    elif ch == '4':
                        val = input("Enter replacement value: ")
                        self.data.fillna(val, inplace=True)
                        print(f"Process Complete: Nulls replaced with '{val}'.")

                    elif ch == '5':
                        break

                else:
                    print("\nAccess Denied: Load data first.")
                    break

        except Exception as e:
            print(f"\nCleaning Error: {e}")

    def dataframe_operations(self):
        """Mathematical operations using NumPy arrays for performance."""

        if self.data is not None:
            print("\n" + "="*15 + " Perform DataFrame Operations " + "="*15)

            if 'Sales' in self.data.columns:
                sales_array = np.array(self.data['Sales'])
                
                print(f"Basic Array View: {sales_array[:5]} ...")
                print(f"Total Sum of Sales: {np.nansum(sales_array):,.2f}") # nansum NaN Not a Number values ignore karega 
                print(f"Highest Sales Record: {np.nanmax(sales_array)}") # like wise in all
                print(f"Lowest Sales Record: {np.nanmin(sales_array)}")
                print(f"Statistical Standard Deviation: {np.nanstd(sales_array):.2f}")
                print(f"Statistical Variance: {np.nanvar(sales_array):.2f}")
                print(f"Array Slicing (Data from index 5 to 15):")
                print(sales_array[5:15])
            else:
                print("Error: 'Sales' column not found in this dataset.")

        else:
            print("\nAccess Denied: Load data first.")

    def search_sort_filter(self):
        """Data manipulation through sorting and filtering."""

        try:
            while True:
                if self.data is not None:
                    print("\n" + "="*15 + " SEARCH, SORT & FILTER " + "="*15)
                    print("1. Sort Dataset by Sales (High to Low)")
                    print("2. Filter Records by a Specific Region")
                    print("3. Search for a Product by Name (Keyword)")
                    print("4. Back to Main Menu")
                    
                    ch = input("\nSelect Action: ")

                    if ch == '1':
                        print(self.data.sort_values(by='Sales', ascending=False).head(15))

                    elif ch == '2':
                        region = input("Enter exact Region Name (e.g., North, West): ")
                        result = self.data[self.data['Region'].str.lower() == region.lower()]
                        print(result if not result.empty else "No records found for this region.")

                    elif ch == '3':
                        prod = input("Enter Product Keyword: ")
                        result = self.data[self.data['Product'].str.contains(prod, case=False, na=False)]# case = search casesansitive, na = ignore nan values
                        print(result if not result.empty else "No matching products found.")

                    elif ch == '4':
                        break

                else:
                    print("\nAccess Denied: Load data first.")

        except Exception as e:
            print(f"\nCleaning Error: {e}")

    def visualize_data(self):
        """Advanced Data Visualization using Seaborn and Matplotlib."""
        
        try:
            while True:
                if self.data is not None:
                    print("\n" + "="*20 + " VISUALIZATION ENGINE " + "="*20)
                    print("1. Bar Plot (Sales per Product)")
                    print("2. Line Plot (Sales Trends)")
                    print("3. Scatter Plot (Sales vs Profit)")
                    print("4. Pie Chart (Market Share by Region)")
                    print("5. Histogram (Distribution of Sales)")
                    print("6. Box Plot (Sales Variation by Region)")
                    print("7. Back to Main Menu")
                    
                    ch = input("\nEnter Chart Type (1-7): ")
                    if ch == '7':
                        break
                    
                    if ch not in ['1', '2', '3', '4', '5', '6']:
                        print("Invalid selection. Please try again.")
                        continue

                    fig = plt.figure(figsize=(12, 7))
                    self.currentfig = fig 
                    sns.set_style("whitegrid")
                    
                    try:
                        if ch == '1':
                            self.data.groupby('Product')['Sales'].sum().sort_values().plot(kind='barh', color='teal')
                            plt.title("Revenue Generated by Each Product")

                        elif ch == '2':
                            plt.plot(self.data['Sales'], marker='o', color='orange', linewidth=1)
                            plt.title("Sales Fluctuation Trend")

                        elif ch == '3':
                            sns.regplot(x='Sales', y='Profit', data=self.data, scatter_kws={'alpha':0.5}) # scatter_kws={'alpha':0.5} scatter points ko thoda transparent banayega
                            plt.title("Correlation Analysis: Sales vs Profit")
                        
                        elif ch == '4':
                            self.data.groupby('Region')['Sales'].sum().plot(kind='pie', autopct='%1.2f%%', shadow=True)
                            plt.ylabel('')
                            plt.title("Regional Sales Contribution")
                        
                        elif ch == '5':
                            sns.histplot(self.data['Sales'], bins=15, kde=True, color='purple') # kde=True se histogram ke sath ek density curve bhi plot hoga
                            plt.title("Density Distribution of Sales")
                        
                        elif ch == '6':
                            sns.boxplot(x='Region', y='Sales', data=self.data, hue='Region', palette="Set2", legend=False)
                            plt.title("Sales Range and Outliers by Region")

                        plt.tight_layout()
                        
                        save = input("\nConfirm: Save this visualization as PNG? (y/n): ")
                        if save.lower() == 'y':
                            fname = input("Enter Filename: ")
                            plt.savefig(fname if fname.endswith('.png') else fname + '.png')
                            print(f"Successfully saved to disk as {fname}")
                        
                        plt.show() # Show the plot after saving (if user chooses to save)

                    except Exception as e:
                        print(f"Plotting Error: {e}")

                else:
                    print("\nError: No data available to visualize.")

        except Exception as e:
            print(f"\nCleaning Error: {e}")

    def save_current_plot(self):
        """Saves the last generated plot to a file."""

        try:
            if self.currentfig is not None:
                fname = input("Enter filename to save current plot (without extension): ")

                if not fname.strip():
                    fname = "visualization"

                self.currentfig.savefig(fname + '.png')
                print(f"Plot saved successfully as {fname}.png")

            else:
                print("No current plot to save.")

        except Exception as e:
            print(f"\nCleaning Error: {e}") 

def main():
    analyzer = SalesDataAnalyzer()
    
    try:
        while True:
            print("\n" + "="*20 + " MAIN CONTROL PANEL " + "="*20)
            print("1. Load Dataset (Only CSV format)")
            print("2. Explore Data")
            print("3. Perform DataFrame Operations")
            print("4. Handle Nulls & Clean Data")
            print("5. Search, Sort and Filter Data")
            print("6. Generate Visualizations (Bar, Line, Scatter, Pie, Histogram, Box)")
            print("7. Save Last Generated Visualization")
            print("8. Exit")
            
            choice = input("\nEnter your Choice (1-8): ")
            
            if choice == '1':
                path = input("Enter full path of CSV file: ")
                analyzer.load_data(path)

            elif choice == '2':
                analyzer.explore_data()

            elif choice == '3':
                analyzer.dataframe_operations()

            elif choice == '4':
                analyzer.clean_data()

            elif choice == '5':
                analyzer.search_sort_filter()

            elif choice == '6':
                analyzer.visualize_data()

            elif choice == '7':
                analyzer.save_current_plot()

            elif choice == '8':
                print("\nShutting down system. Goodbye!")
                break

            else:
                print("\nInvalid Selection: Please choose between 1 and 8.")

    except Exception as e:
            print(f"\nCleaning Error: {e}")

if __name__ == "__main__":
    main()